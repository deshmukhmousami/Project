package com.cricket.utils;


public interface CommonUtils {

    void printWinnerOfMatch(int totalScoreByTeam1, int totalScoreByTeam2);

}
