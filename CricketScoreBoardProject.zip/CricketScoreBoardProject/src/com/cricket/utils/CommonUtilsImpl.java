package com.cricket.utils;

import com.cricket.utils.CommonUtils;

public class CommonUtilsImpl implements CommonUtils {


    @Override
    public void printWinnerOfMatch(int totalScoreByTeam1, int totalScoreByTeam2) {
        System.out.println("Score of team1= "+totalScoreByTeam1+" Score of team2= "+totalScoreByTeam2);
        if(totalScoreByTeam2>totalScoreByTeam1){
            System.out.println("MATCH IS WON BY team2 by"+(totalScoreByTeam2-totalScoreByTeam1));
        }
        if(totalScoreByTeam2<totalScoreByTeam1){
            System.out.println("MATCH IS WON BY team1 by "+(totalScoreByTeam1-totalScoreByTeam2));
        }
        if(totalScoreByTeam2==totalScoreByTeam1){
            System.out.println("MATCH IS A TIE");
        }

    }
}
