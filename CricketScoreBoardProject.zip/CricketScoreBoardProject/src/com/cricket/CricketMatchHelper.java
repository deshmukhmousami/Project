package com.cricket;

import com.cricket.entity.Score;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class CricketMatchHelper {


    public static int print(List<List<String>> overs, Set<String> playerNamesSet, Map<String, Score> playersMap, int striker, int nonStriker, int sum) {
        List<String> playerNameList = playerNamesSet.stream().collect(Collectors.toList());
        int index = 1;
        for (int overNo = 0; overNo < overs.size(); overNo++) {
            List<String> oversList = overs.get(overNo);
            System.out.println("Current Overs list is " + oversList);
            boolean flag = true;
            sum = 0;
            for (int j = 0; j < oversList.size(); j++) {
                if (flag == true) {
                    Score run = playersMap.get(playerNameList.get(striker));
                    System.out.println("Player playing is ---" + playerNameList.get(striker) + " facing ball ---" + oversList.get(j));
                    if (oversList.get(j) == "W") {
                        System.out.println("Out at index =" + playerNameList.get(striker));
                        index++;
                        if (index > playerNameList.size() - 1) {
                            System.out.println("---Over " + (overNo + 1) + " ended ----");
                            break;
                        }
                        striker = index;
                        System.out.println("New bats man after out will be =" + playerNameList.get(striker));
                        continue;
                    }
                    if (oversList.get(j) == "Wd") {
                        sum += 1;
                        continue;
                    }
                    int ballType = Integer.parseInt(oversList.get(j));
                    if (ballType == 1) {
                        int balls = run.getNoOfBalls() + 1;
                        run.setNoOfBalls(balls);
                        run.setNoOf1s(run.getNoOf1s() + 1);
                    }

                    if (ballType == 2) {
                        int balls = run.getNoOfBalls() + 1;
                        run.setNoOfBalls(balls);
                        run.setNoOf2s(1 + run.getNoOf2s());
                    }

                    if (ballType == 4) {
                        int balls = run.getNoOfBalls() + 1;
                        run.setNoOfBalls(balls);
                        run.setNoOf4s(run.getNoOf4s() + 1);
                    }
                    if (ballType == 6) {
                        int balls = run.getNoOfBalls() + 1;
                        run.setNoOfBalls(balls);
                        run.setNoOf6s(run.getNoOf6s() + 1);
                    }

                    playersMap.put(playerNameList.get(striker), run);
                    System.out.println("Putting for player =" + playerNameList.get(striker) + " run entry=" + run.toString());
                    if (!(oversList.get(j).equals("Wd") || (oversList.get(j).equals("W"))) && (Integer.parseInt(oversList.get(j)) % 2) != 0) {
                        flag = false;
                    }

                } else {
                    Score run = playersMap.get(playerNameList.get(nonStriker));
                    System.out.println("Player playing is ---" + playerNameList.get(nonStriker) + " facing ball ---" + oversList.get(j));
                    if (oversList.get(j) == "W") {
                        System.out.println("Out at index =" + playerNameList.get(nonStriker));
                        index++;
                        if (index > playerNameList.size() - 1) {
                            System.out.println("---Over " + (overNo + 1) + " ended ----");
                            break;
                        }
                        nonStriker = index;
                        System.out.println("New bats man after out will be =" + playerNameList.get(nonStriker));
                        continue;
                    }
                    if (oversList.get(j) == "Wd") {
                        sum += 1;
                        continue;
                    }
                    int ballType = Integer.parseInt(oversList.get(j));
                    playersMap.put(playerNameList.get(nonStriker), Score.runsOfPlayer(ballType,run));
                    if (!(oversList.get(j).equals("Wd") || (oversList.get(j).equals("W"))) && (Integer.parseInt(oversList.get(j)) % 2) != 0) {
                        flag = true;
                    }

                }

            }
            System.out.println("Name" + " 4s " + " 6s " + " 2s " + " 1s " + " totalBalls " + " totalRuns ");
            for (Map.Entry<String, Score> entry : playersMap.entrySet()) {
                entry.getValue().setTotalRuns(1 * entry.getValue().getNoOf1s() + 2 * entry.getValue().getNoOf2s() + 4 * entry.getValue().getNoOf4s() + 6 * entry.getValue().getNoOf6s());
                System.out.println(entry.getKey() + "   " + entry.getValue().getNoOf4s() + "   " + entry.getValue().getNoOf6s() + "   " + entry.getValue().getNoOf2s() + "   " + entry.getValue().getNoOf1s() + "       " + entry.getValue().getNoOfBalls() + "           " + entry.getValue().getTotalRuns());
                sum = sum + entry.getValue().getTotalRuns();
            }
            System.out.println("Sum after" + (overNo + 1) + " over is =" + sum);
        }
        return sum;
    }

}
