package com.cricket;
import com.cricket.entity.Score;
import com.cricket.utils.CommonUtilsImpl;

import java.util.*;

public class Main {

    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
		Map<String, Score>  playersMap = new LinkedHashMap<String,Score>();
		Set<String> playerNamesSet = new LinkedHashSet<>();
		playerNamesSet.add("P1");
		playerNamesSet.add("P2");
		playerNamesSet.add("P3");
		playerNamesSet.add("P4");
		playerNamesSet.add("P5");
		for(int a=0;a<5;a++){
			playersMap.put(playerNamesSet.toArray()[a].toString(),new Score(0,0,0,0,0,0));
		}

		List<String> overs1List = new ArrayList<String>( Arrays.asList("1","1","1","1","1","2"));
		List<String> overs2List = new ArrayList<String>( Arrays.asList("W","4","4","Wd","W","1","6"));
		List<List<String>> overs = new ArrayList<>(Arrays.asList(overs1List,overs2List));
		System.out.println("-----------------------TEAM-1 started playing ----------------------");
		int totalScoreByTeam1 = CricketMatchHelper.print(overs,playerNamesSet,playersMap,0,1,0);


		System.out.println("");
		Map<String,Score>  playersMap2 = new LinkedHashMap<String,Score>();
		Set<String> playerNamesSet2 = new LinkedHashSet<>();
		playerNamesSet2.add("P6");
		playerNamesSet2.add("P7");
		playerNamesSet2.add("P8");
		playerNamesSet2.add("P9");
		playerNamesSet2.add("P10");
		for(int a=0;a<5;a++){
			playersMap2.put(playerNamesSet2.toArray()[a].toString(),new Score(0,0,0,0,0,0));
		}
		List<String> overs1List2 = new ArrayList<String>( Arrays.asList("4","6","W","W","1","1"));
		List<String> overs2List2 = new ArrayList<String>( Arrays.asList("6","1","W","W"));
		List<List<String>> overs2 = new ArrayList<>(Arrays.asList(overs1List2,overs2List2));
		System.out.println("-------------------- TEAM-2 started playing -------------------------");
		int totalScoreByTeam2 = CricketMatchHelper.print(overs2,playerNamesSet2,playersMap2,0,1,0);
		CommonUtilsImpl commonUtilsObject = new CommonUtilsImpl();
		commonUtilsObject.printWinnerOfMatch(totalScoreByTeam1,totalScoreByTeam2);

    }
}
