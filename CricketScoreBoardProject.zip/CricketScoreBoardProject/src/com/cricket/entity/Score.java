package com.cricket.entity;

import lombok.Data;

@Data
public class Score {

    private int noOf4s;
    private int noOf6s;
    private int noOf2s;
    private int noOf1s;
    private int noOfBalls;
    private int totalRuns;

    public Score(int noOf4s,int noOf6s,int noOf2s,int noOf1s,int noOfBalls,int totalRuns){
        this.noOf4s=noOf4s;
        this.noOf6s=noOf6s;
        this.noOf1s=noOf1s;
        this.noOfBalls=noOfBalls;
        this.totalRuns=totalRuns;
    }

    @Override
    public String toString() {
        return String.format("noOf4s=" +noOf4s+ ", noOf6s=" + noOf6s+" , noOf2s="+noOf2s+" , noOf1s="+noOf1s+" , noOfBalls="+noOfBalls+" , totalRuns="+totalRuns);
    }

    public static Score runsOfPlayer(int ballType,Score run){
        if (ballType == 1) {
            int balls = run.getNoOfBalls() + 1;
            run.setNoOfBalls(balls);
            int noOf1s = run.getNoOf1s() + 1;
            run.setNoOf1s(noOf1s);
        }
        if (ballType == 2) {
            int balls = run.getNoOfBalls() + 1;
            run.setNoOfBalls(balls);
            run.setNoOf2s(1 + run.getNoOf2s());
        }

        if (ballType == 4) {
            int balls = run.getNoOfBalls() + 1;
            run.setNoOfBalls(balls);
            run.setNoOf4s(1 + run.getNoOfBalls());
        }
        if (ballType == 6) {
            int balls = run.getNoOfBalls() + 1;
            run.setNoOfBalls(balls);
            run.setNoOf6s(run.getNoOf6s() + 1);
        }
        return run;
    }
}
